import React from 'react';
import logo from '../assets/logo.png';
import { Typography } from '@mui/material';

const Header: React.FC = () => {
  return (
    // <div style={{ display: "flex", justifyContent: "center" }} >
    //   {/* <img src={logo} alt="Logo" style={{ height: "80px" }} /> */}
    //   <Typography
    //     variant="h1"
    //     align="center"
    //     sx={{
    //       fontFamily: "'Raleway', sans-serif",
    //       fontWeight: 800,
    //       fontSize: '3rem',
    //       color: '#fa0',
    //       letterSpacing: '0.05em',
    //       marginBottom: '1rem',
    //       textShadow: "3px 3px 3px rgba(20, 22, 25, .431372549)"
    //     }}
    //   >
    //     Universal SQL Editor
    //   </Typography>
    // </div>
    <></>
  );
};

export default Header;